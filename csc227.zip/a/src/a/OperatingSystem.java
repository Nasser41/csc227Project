package a;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.io.*;

enum ProcessState {
    NEW, READY, RUNNING, WAITING, TERMINATED
}

class PCB {
    private final int pid;
    private final int burstTime;
    private final int memoryRequired;
    int remainingTime;
    ProcessState state;
    int waitingTime;
    int turnaroundTime;
    int arrivalTime;
    int lastExecutedTime;

    public PCB(int pid, int burstTime, int memoryRequired) {
        this.pid = pid;
        this.burstTime = burstTime;
        this.memoryRequired = memoryRequired;
        this.remainingTime = burstTime;
        this.state = ProcessState.NEW;
        this.waitingTime = 0;
        this.turnaroundTime = 0;
        this.arrivalTime = 0;
        this.lastExecutedTime = 0;
    }

    public int getPid() {
        return pid;
    }

    public int getBurstTime() {
        return burstTime;
    }

    public int getMemoryRequired() {
        return memoryRequired;
    }
}

class Memory {
    int totalMemory;
    int usedMemory;

    public Memory(int totalMemory) {
        this.totalMemory = totalMemory;
        this.usedMemory = 0;
    }

    public synchronized boolean allocate(int memoryRequired) {
        if (usedMemory + memoryRequired <= totalMemory) {
            usedMemory += memoryRequired;
            return true;
        }
        return false;
    }

    public synchronized void deallocate(int memoryReleased) {
        usedMemory -= memoryReleased;
    }
}


class SystemCallInterface {
    private OperatingSystem os;

    public SystemCallInterface(OperatingSystem os) {
        this.os = os;
    }

    public void createProcess(int pid, int burstTime, int memoryRequired) {
        PCB pcb = new PCB(pid, burstTime, memoryRequired);
        os.addToJobQueue(pcb);
        os.pcbMap.put(pid, pcb); // Add PCB to the map
    }

    public void terminateProcess(int pid) {
        PCB pcb = os.getPCB(pid);
        if (pcb != null && pcb.state != ProcessState.TERMINATED) {
            pcb.state = ProcessState.TERMINATED;
            os.memory.deallocate(pcb.getMemoryRequired());
        }
    }


    public boolean allocateMemory(int pid, int memoryRequired) {
        return os.memory.allocate(memoryRequired);
    }
}


public class OperatingSystem {

    Collection<PCB> jobQueue;
    ConcurrentLinkedQueue<PCB> readyQueue;

    Memory memory;

    
    int systemTime;
    private int totalWaitingTime = 0;
    private int totalTurnaroundTime = 0;
    private int processCount = 0;

    Thread jobLoaderThread;
    Thread jobToReadyLoaderThread;

   
    SystemCallInterface sysCall;

    Map<Integer, PCB> pcbMap;

    public OperatingSystem() {
        
    }

   
    public void addToJobQueue(PCB pcb) {
        jobQueue.add(pcb);
    }

   
    public PCB getPCB(int pid) {
        return pcbMap.get(pid); 
    }

   
    public void startSimulation(int schedulingAlgorithm, String filename) {
     
        pcbMap = new HashMap<>();
        readyQueue = new ConcurrentLinkedQueue<>();
        memory = new Memory(1024);
        systemTime = 0;
        sysCall = new SystemCallInterface(this);

      
        if (schedulingAlgorithm == 3) { // SJF
            jobQueue = Collections.synchronizedList(new ArrayList<PCB>());
        } else {
            jobQueue = new ConcurrentLinkedQueue<>();
        }

       
        jobLoaderThread = new Thread(() -> {
            loadJobs(filename);
        });

     
        jobToReadyLoaderThread = new Thread(() -> {
            moveJobsToReady(schedulingAlgorithm);
        });

       
        jobLoaderThread.start();
        jobToReadyLoaderThread.start();

      
        switch (schedulingAlgorithm) {
            case 1:
                fcfsScheduling();
                break;
            case 2:
                rrScheduling(10); 
                break;
            case 3:
                sjfScheduling();
                break;
            default:
                System.out.println("Invalid scheduling algorithm selected.");
                return;
        }

      
        if (processCount > 0) {
            double avgWaitingTime = (double) totalWaitingTime / processCount;
            double avgTurnaroundTime = (double) totalTurnaroundTime / processCount;

            System.out.println("Average Waiting Time: " + avgWaitingTime + " ms");
            System.out.println("Average Turnaround Time: " + avgTurnaroundTime + " ms");
        } else {
            System.out.println("No processes were executed.");
        }
    }

   
    public void loadJobs(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            int arrivalTime = 0;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("[") || line.trim().isEmpty()) {
                    continue;
                }
                String[] parts = line.split("[:;]");
                int pid = Integer.parseInt(parts[0].trim());
                int burstTime = Integer.parseInt(parts[1].trim());
                int memoryRequired = Integer.parseInt(parts[2].trim());
                sysCall.createProcess(pid, burstTime, memoryRequired);
                PCB pcb = getPCB(pid);
                pcb.arrivalTime = arrivalTime; 
                arrivalTime += 0; 
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    public void moveJobsToReady(int schedulingAlgorithm) {
        if (schedulingAlgorithm == 3) { 
            List<PCB> jobList = (List<PCB>) jobQueue;
            while (jobLoaderThread.isAlive() || !jobList.isEmpty()) {
                synchronized (jobList) {
                    // Sort the jobList based on burst time
                    jobList.sort(Comparator.comparingInt(PCB::getBurstTime));
                    Iterator<PCB> iterator = jobList.iterator();
                    boolean progressMade = false;
                    while (iterator.hasNext()) {
                        PCB pcb = iterator.next();
                        if (sysCall.allocateMemory(pcb.getPid(), pcb.getMemoryRequired())) {
                            pcb.state = ProcessState.READY;
                            readyQueue.add(pcb);
                            iterator.remove();
                            progressMade = true;
                        }
                    }
                    if (!progressMade) {
                        
                        try {
                            jobList.wait(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } catch (IllegalMonitorStateException e) {
                          
                            try {
                                Thread.sleep(10);
                            } catch (InterruptedException ex) {
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }
        } else { 
            Queue<PCB> jobQueueQueue = (Queue<PCB>) jobQueue;
            while (jobLoaderThread.isAlive() || !jobQueueQueue.isEmpty()) {
                try {
                    PCB pcb = jobQueueQueue.peek();
                    if (pcb != null) {
                        if (sysCall.allocateMemory(pcb.getPid(), pcb.getMemoryRequired())) {
                            pcb.state = ProcessState.READY;
                            readyQueue.add(jobQueueQueue.poll());
                        } else {
                           
                            Thread.sleep(10); 
                        }
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

   
    public void fcfsScheduling() {
        System.out.println("\nFCFS Scheduling:");
        while (jobLoaderThread.isAlive() || jobToReadyLoaderThread.isAlive() || !readyQueue.isEmpty()) {
            PCB pcb = readyQueue.poll();
            if (pcb != null) {
                pcb.state = ProcessState.RUNNING;
                pcb.waitingTime = systemTime - pcb.arrivalTime;
                System.out.println("Time " + systemTime + ": Process " + pcb.getPid() + " started.");
                systemTime += pcb.remainingTime;
                pcb.remainingTime = 0;
                pcb.lastExecutedTime = systemTime;
                pcb.turnaroundTime = systemTime - pcb.arrivalTime;
                sysCall.terminateProcess(pcb.getPid());
                System.out.println("Time " + systemTime + ": Process " + pcb.getPid() + " terminated.");
                // Accumulate totals
                totalWaitingTime += pcb.waitingTime;
                totalTurnaroundTime += pcb.turnaroundTime;
                processCount++;
            } else {
                // No process is ready; wait for a short time
                try {
                    Thread.sleep(10);
                    systemTime += 10;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Round-Robin Scheduling (Main Thread)
    public void rrScheduling(int quantum) {
        System.out.println("\nRound Robin Scheduling:");
        int currentTime = systemTime;
        List<PCB> rrQueue = new ArrayList<>();

        while (jobLoaderThread.isAlive() || jobToReadyLoaderThread.isAlive() || !readyQueue.isEmpty() || !rrQueue.isEmpty()) {
            while (!readyQueue.isEmpty()) {
                rrQueue.add(readyQueue.poll());
            }
            if (!rrQueue.isEmpty()) {
                Iterator<PCB> iterator = rrQueue.iterator();
                while (iterator.hasNext()) {
                    PCB pcb = iterator.next();
                    pcb.state = ProcessState.RUNNING;
                    // Calculate waiting time since last execution or arrival
                    pcb.waitingTime += currentTime - pcb.lastExecutedTime;
                    int execTime = Math.min(quantum, pcb.remainingTime);
                    System.out.println("Time " + currentTime + ": Process " + pcb.getPid() + " executing for " + execTime + " ms.");
                    currentTime += execTime;
                    pcb.remainingTime -= execTime;
                    pcb.lastExecutedTime = currentTime;

                    if (pcb.remainingTime == 0) {
                        sysCall.terminateProcess(pcb.getPid());
                        pcb.turnaroundTime = currentTime - pcb.arrivalTime;
                        System.out.println("Time " + currentTime + ": Process " + pcb.getPid() + " terminated.");
                        // Accumulate totals
                        totalWaitingTime += pcb.waitingTime;
                        totalTurnaroundTime += pcb.turnaroundTime;
                        processCount++;
                        iterator.remove();
                    } else {
                        pcb.state = ProcessState.READY;
                    }
                }
            } else {
                // No process is ready; wait for a short time
                try {
                    Thread.sleep(10);
                    currentTime += 10;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        // Update the systemTime to reflect the total time elapsed
        systemTime = currentTime;
    }

    // Shortest Job First Scheduling (Main Thread)
    public void sjfScheduling() {
        System.out.println("\nSJF Scheduling:");
        while (jobLoaderThread.isAlive() || jobToReadyLoaderThread.isAlive() || !readyQueue.isEmpty()) {
            PCB pcb = readyQueue.poll();
            if (pcb != null) {
                pcb.state = ProcessState.RUNNING;
                pcb.waitingTime = systemTime - pcb.arrivalTime;
                System.out.println("Time " + systemTime + ": Process " + pcb.getPid() + " started.");
                systemTime += pcb.remainingTime;
                pcb.remainingTime = 0;
                pcb.lastExecutedTime = systemTime;
                pcb.turnaroundTime = systemTime - pcb.arrivalTime;
                sysCall.terminateProcess(pcb.getPid());
                System.out.println("Time " + systemTime + ": Process " + pcb.getPid() + " terminated.");
                // Accumulate totals
                totalWaitingTime += pcb.waitingTime;
                totalTurnaroundTime += pcb.turnaroundTime;
                processCount++;
            } else {
                // No process is ready; wait for a short time
                try {
                    Thread.sleep(10);
                    systemTime += 10;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        do {
            OperatingSystem os = new OperatingSystem();

            System.out.println("Select Scheduling Algorithm:" + "\n"
                    + "1. First-Come-First-Serve (FCFS)" + "\n"
                    + "2. Round-Robin (RR)" + "\n"
                    + "3. Shortest Job First (SJF)" + "\n\n"
                    + "Select Option [enter 0 to exit]: ");
            int schedulingAlgorithm = scanner.nextInt();

            if (schedulingAlgorithm == 0)
                break;
            else if (schedulingAlgorithm < 1 || schedulingAlgorithm > 3) {
                System.out.println("Please enter number from 1 to 3. [enter 0 to exit]");
                continue;
            }

            os.startSimulation(schedulingAlgorithm, "job.txt");
        } while (true);

        scanner.close();
        System.out.println("Thank you for using our program! :)");
    }
}
